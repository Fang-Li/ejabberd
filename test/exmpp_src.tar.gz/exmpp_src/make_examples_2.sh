rm -rf ebin/* ; erlc -o ebin/ examples_2/*.erl ; cp examples_2/tx.app ebin/tx.app 

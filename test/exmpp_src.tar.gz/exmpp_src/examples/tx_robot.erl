-module(tx_robot).

-record(robot,{name,counter}).
-record(status,{id,total}).

-define(RN,"robot-").

-export([
	start/0
]).

start() ->
	%% TODO 随机得到的名字
	Name = get_name(),
	register( Name , spawn(fun()-> loop(Name) end) ).

rpc(P,Q) when is_pid(P) ->
	P!{self(),Q},
	receive
		{P,Reply} ->
			Reply
	end.

loop(RN)->
	io:format("heart beat... ~p~n",[RN]),
	receive 
		{From, {store,Key,Value} } ->
			From!{kvs,true},
			loop(RN)
	after 30000 ->
		loop(RN)
	end.

get_name()->
	{I1,I2,I3} = os:timestamp(),
	ID = ?RN++integer_to_list(I1)++integer_to_list(I2)++integer_to_list(I3),
	mnesia:dirty_write(#robot{name=ID,counter=[]}),
	ID.


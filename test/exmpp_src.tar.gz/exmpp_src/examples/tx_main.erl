-module(tx_main).

-include_lib("exmpp/include/exmpp.hrl").
-include_lib("exmpp/include/exmpp_client.hrl").

-behaviour(gen_server).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2, code_change/3]).

%% ====================================================================
%% API functions
%% ====================================================================
-export([
	start_link/0,
	start/1
]).

-record(robot,{name,counter}).
-record(log,{id,total}).

-record(state, {
	  session,
	  name,
	  passwd="pet-service-manager",
	  domain="test.com",
	  host="127.0.0.1",
	  port=5222
}).

-define(RN,"robot-").
%% timer
-define(T,5000).

start(T) ->
	log4erl:debug("tx_main line=~p :::> T=~p~n",[?LINE,T]),
	ID = calendar:local_time(),
	mnesia:dirty_write(#log{id=ID,total=T}),
	log4erl:info("task begin at : ~p",[ID]),
	create_robot(0,T).
create_robot(I,Total) when I=/=Total ->
	log4erl:debug("tx_main line=~p :::> I=~p ; Total=~p~n",[?LINE,I,Total]),
	%% 启动一个可监控进程,此处回调 start_link/0 完成初始化
	{ok,Pid} = tx_main_sup:start_child(),
	log4erl:info("PPPPPPPPPPPPPPPPP========== ~p",[Pid]),
	gen_server:cast(Pid,{timer,Pid}),
	create_robot(I+1,Total);
create_robot(I,I)->
	ok.

start_link() ->
	%% 此处回调 init/1 完成初始化
	Name = get_name(),
	{ok,Pid} = gen_server:start_link(?MODULE,[Name],[]),
	log4erl:info("-- file=~p;line=~p;name=~p;pid=~p --",[?FILE,?LINE,Name,Pid]),
	{ok,Pid}.

get_name()->
	{I1,I2,I3}=os:timestamp(),
	Name=?RN++integer_to_list(I1)++integer_to_list(I2)++integer_to_list(I3),
	mnesia:dirty_write(#robot{name=Name}),
	Name.



%% ====================================================================
%% Behavioural functions 
%% ====================================================================

%% init/1
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:init-1">gen_server:init/1</a>
-spec init(Args :: term()) -> Result when
	Result :: {ok, State} | {ok, State, Timeout} | {ok, State, hibernate} | {stop, Reason :: term()} | ignore,
	State :: term(),
	Timeout :: non_neg_integer() | infinity.
%% ====================================================================
init([Name|L]) ->
	%% TODO create robot instance 	
	State = #state{},
	log4erl:info("-- robot up line=~p ; Name=~p ; state=~p--",[?LINE,Name,State]),
	#state{domain=Domain,host=Host,passwd=Passwd,port=Port}=State,
	try
		application:start(exmpp),
		MySession = exmpp_session:start(),
		MyJID = exmpp_jid:make(Name,Domain),
		%% Method = password | digest | "PLAIN" | "ANONYMOUS" | "DIGEST-MD5" | string()
		exmpp_session:auth_method(MySession,"PLAIN"),		
		exmpp_session:auth_basic(MySession,MyJID,Passwd),
		{ok,_StreamId} = exmpp_session:connect_TCP(MySession,Host,Port),	
		exmpp_session:login(MySession),
		Presence = exmpp_presence:set_status(exmpp_presence:available(),"Echo Ready"),
		exmpp_session:send_packet(MySession,Presence),
		log4erl:info("start tx_main ok :::>Name=~p; login and presence",[Name]),
		%% last param is set timeout
		{ok,State#state{session=MySession,name=Name},0}
	catch
		ERR:INFO ->	
			log4erl:error("start tx_main error :::>Name=~p;ERR=~p;INFO=~p",[Name,ERR,INFO]),
			{stop, {Name,ERR,INFO}}
	end.

%%loop(MSession)->
%%	receive 
%%		stop ->
%%			ok;
%%		Record ->
%%			log4erl:info("Record ::::> ~p",[Record]),
%%			loop(MSession)
%%	after 5000 ->
%%			log4erl:info("hert beat ..."),
%%		      	loop(MSession)
%%	end.


%% handle_call/3
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:handle_call-3">gen_server:handle_call/3</a>
-spec handle_call(Request :: term(), From :: {pid(), Tag :: term()}, State :: term()) -> Result when
	Result :: 	  {reply, Reply, NewState}
			| {reply, Reply, NewState, Timeout}
			| {reply, Reply, NewState, hibernate}
			| {noreply, NewState}
			| {noreply, NewState, Timeout}
			| {noreply, NewState, hibernate}
			| {stop, Reason, Reply, NewState}
			| {stop, Reason, NewState},
	Reply :: term(),
	NewState :: term(),
	Timeout :: non_neg_integer() | infinity,
	Reason :: term().
%% ====================================================================
handle_call(Request, From, State) ->
    Reply = ok,
    {reply, Reply, State}.


%% handle_cast/2
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:handle_cast-2">gen_server:handle_cast/2</a>
-spec handle_cast(Request :: term(), State :: term()) -> Result when
	Result :: {noreply, NewState}
			| {noreply, NewState, Timeout}
			| {noreply, NewState, hibernate}
			| {stop, Reason :: term(), NewState},
	NewState :: term(),
	Timeout :: non_neg_integer() | infinity.
%% ====================================================================
%% 在这里完成定时
handle_cast({timer,Pid}, State) ->
	timer:sleep(?T),
	%% TODO 在这判断是否有必要执行新的任务
	All = mnesia:dirty_all_keys(robot),
	Len = length(All),
	case Len of
		N when N > 10 ->
			{I1,I2,I3} = os:timestamp(),
			Str = integer_to_list(I1)++integer_to_list(I2)++integer_to_list(I3),
			I = ( list_to_integer(Str) rem N )+1,
			case element(I,list_to_tuple(All)) of 
				Target when Target=/=State#state.name ->
					Domain = State#state.domain,
					{jid,From,_,_,_} = exmpp_jid:make(State#state.name,Domain),
					{jid,To,_,_,_}   = exmpp_jid:make(Target,Domain),
					Message0 = exmpp_message:chat("Hello girls ,are free tonight"),
					Message1 = exmpp_xml:set_attribute(Message0, <<"from">>, From),
					Message2 = exmpp_xml:set_attribute(Message1, <<"to">>, To),
					Message3 = exmpp_xml:set_attribute(Message2, <<"id">>, Str),
					Message4 = exmpp_xml:set_attribute(Message3, <<"msgtype">>, "normalchat"),
					Message5 = exmpp_xml:set_attribute(Message4, <<"type">>, "chat"),
					log4erl:info("SEND==~p",[Message5]),
					exmpp_session:send_packet(State#state.session,Message5),
					do;
				_ ->
					equal
			end;
		_ ->
			skip
	end,
	gen_server:cast(Pid,{timer,Pid}),	
	{noreply, State};
handle_cast(stop, State) ->
	{stop, normal, State}.


%% handle_info/2
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:handle_info-2">gen_server:handle_info/2</a>
-spec handle_info(Info :: timeout | term(), State :: term()) -> Result when
	Result :: {noreply, NewState}
			| {noreply, NewState, Timeout}
			| {noreply, NewState, hibernate}
			| {stop, Reason :: term(), NewState},
	NewState :: term(),
	Timeout :: non_neg_integer() | infinity.
%% ====================================================================
handle_info(Record=#received_packet{packet_type=message,raw_packet=Packet,type_attr=Type}, State) when Type=/= "error" ->
	log4erl:debug("Message=~p",[Packet]),
	From = exmpp_xml:get_attribute(Packet, <<"to">>, <<"unknown">>),
	To = exmpp_xml:get_attribute(Packet, <<"from">>, <<"unknown">>),
	Id = exmpp_xml:get_attribute(Packet, <<"id">>, <<"unknown">>),
	log4erl:info("RECEIVE==~p",[Packet]),
	case exmpp_xml:get_attribute(Packet, <<"msgtype">>, <<"unknow">>) of
		<<"normalchat">> ->
			Message0 = exmpp_message:chat("fine"),
			Message1 = exmpp_xml:set_attribute(Message0, <<"from">>, From),
			Message2 = exmpp_xml:set_attribute(Message1, <<"to">>, To),
			Message3 = exmpp_xml:set_attribute(Message2, <<"id">>, Id),
			Message4 = exmpp_xml:set_attribute(Message3, <<"msgtype">>, "msgStatus"),
			Message5 = exmpp_xml:set_attribute(Message4, <<"type">>, "normal"),
			log4erl:info("ACK==~p",[Message5]),
			exmpp_session:send_packet(State#state.session,Message5);
		_Other ->
			skip
			%% log4erl:info("revice message : msgtype=~p",[_Other])
	end,
	%% <message id='10001' from='y@y.y' to='x@x.x' msgtype='msgStatus' type='normal'>...</message>
    	{noreply, State};
handle_info(Record,State) when Record#received_packet.packet_type =/= 'message' ->
	log4erl:debug("Record=~p",[Record]),
	{noreply,State};
handle_info(timeout,State)->
	%% other options
	{noreply,State}.


%% terminate/2
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:terminate-2">gen_server:terminate/2</a>
-spec terminate(Reason, State :: term()) -> Any :: term() when
	Reason :: normal
			| shutdown
			| {shutdown, term()}
			| term().
%% ====================================================================
terminate(Reason, State) ->
    ok.


%% code_change/3
%% ====================================================================
%% @doc <a href="http://www.erlang.org/doc/man/gen_server.html#Module:code_change-3">gen_server:code_change/3</a>
-spec code_change(OldVsn, State :: term(), Extra :: term()) -> Result when
	Result :: {ok, NewState :: term()} | {error, Reason :: term()},
	OldVsn :: Vsn | {down, Vsn},
	Vsn :: term().
%% ====================================================================
code_change(OldVsn, State, Extra) ->
    {ok, State}.


%% ====================================================================
%% Internal functions
%% ====================================================================


